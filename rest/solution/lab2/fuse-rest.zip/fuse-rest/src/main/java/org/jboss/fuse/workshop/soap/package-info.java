@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.workshop.fuse.jboss.org/")
package org.jboss.fuse.workshop.soap;
